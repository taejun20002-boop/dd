summon shadow_creatures:meadow_wolf ~4 ~ ~
summon shadow_creatures:meadow_slime ~ ~ ~4
summon shadow_creatures:meadow_golem ~-4 ~ ~
tellraw @s {"text":"Lv.1 테스트 몬스터 3종 생성. 크리에이티브에서는 적이 공격하지 않을 수 있습니다.","color":"gold"}
